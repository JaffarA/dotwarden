# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dotwarden']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'dotwarden',
    'version': '1.0.0',
    'description': 'a utility for generating hidden random . directories',
    'long_description': None,
    'author': 'Jaffar',
    'author_email': 'jaffar.almaleki@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.4,<4.0',
}


setup(**setup_kwargs)
